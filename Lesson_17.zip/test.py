# Создание таблиц в базе данных:
from .db import Base

def create_database():
    Base.metadata.create_all(bind=engine)


#  Объяснение кода :
# db.py: Создается движок базы данных SQLite, сессия и базовый
# класс длям оделей.
# user.py и task.py: Определяются модели User и Task с
# соответствующими атрибутами и связями.
# init.py: Обеспечивает удобный импорт моделей в другие модули.
# create_database: Функция для  создания таблиц в базе данных.
#

# Использование моделей :

from sqlalchemy.orm import Session

# Создаем сессию
db = SessionLocal()

# Создаем нового пользователя
new_user = User(username="user1", firstname="John", lastname="Doe", age=30, slug="john-doe")
db.add(new_user)
db.commit()
db.refresh(new_user)

# Создаем новую задачу
new_task = Task(title="Task 1", content="Do something", user=new_user, slug="task-1")
db.add(new_task)
db.commit()